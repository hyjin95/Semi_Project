package semi_project.test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Payment extends JFrame implements ActionListener {
	MovieMainView mmv = null;
	
	JPanel jp_center = new JPanel();
	JPanel jp_south = new JPanel();
	
	JLabel jlb_card = new JLabel("카드사");
		String[] card_name= {"BC카드", "삼성카드", "신한카드", "현대카드", "하나카드", "국민카드", "롯데카드"};
	JComboBox jcb_card = new JComboBox(card_name);
	
	JLabel jlb_cdn = new JLabel("카드번호");
	JTextField jtf_cdn = new JTextField(30);
	
	JLabel jlb_expire = new JLabel("유효기간");
	JTextField jtf_expire = new JTextField(30);
	
	JLabel jlb_price = new JLabel("결제금액");
	JTextField jtf_price = new JTextField(30);
	
	JLabel jlb_cvc = new JLabel("CVC코드");
	JTextField jtf_cvc = new JTextField(30);
	
	JButton jbtn_payment = new JButton("결제하기");
	JButton jbtn_exit = new JButton("닫기");
	
	public void initDisplay() {
		jp_center.setLayout(null); // 레이아웃 뭉갬
		
		jlb_card.setBounds (40, 20, 50, 20); 
		jcb_card.setBounds (110, 20, 100, 20);
		jlb_cdn.setBounds(40, 45 ,80  ,20);
		jtf_cdn.setBounds(110, 45 ,100 ,20);
		jlb_expire.setBounds(40, 70, 80, 20);
		jtf_expire.setBounds(110, 70, 100, 20);
		jlb_cvc.setBounds(40, 95, 80, 20);
		jtf_cvc.setBounds(110, 95, 100, 20);
		jlb_price.setBounds(40, 150, 80, 20);
		jtf_price.setBounds(110, 150, 100, 20);
		
		jp_center.add(jlb_card);
		jp_center.add(jcb_card);
		jp_center.add(jlb_cdn);
		jp_center.add(jtf_cdn);
		jp_center.add(jlb_expire);
		jp_center.add(jtf_expire);
		jp_center.add(jlb_cvc);
		jp_center.add(jtf_cvc);
		jp_center.add(jlb_price);
		jp_center.add(jtf_price);
		
		jbtn_exit.addActionListener(this);
		jbtn_payment.addActionListener(this);
		
		jp_south.add(jbtn_payment);
		jp_south.add(jbtn_exit);
		this.setTitle("결제");
		this.add("Center",jp_center);
		this.add("South",jp_south);
		this.setSize(300, 350);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		new Payment().initDisplay();
	}
	
	public int ranCom() {
		return (int)(Math.random()*1000000);
	}

	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		
		if(obj == jbtn_payment) {
			MovieMainView.Ticketing_num = ranCom();
			JOptionPane.showMessageDialog(null, "결제가 완료되었습니다.!\n 예매번호는 " + 
					MovieMainView.Ticketing_num + "번 입니다!", "결제완료", JOptionPane.PLAIN_MESSAGE);
			this.setVisible(false);
			mmv = new MovieMainView();
			mmv.initDisplay();
			
		}
		
		if(obj == jbtn_exit) {
			System.exit(0);
		}
	}
}
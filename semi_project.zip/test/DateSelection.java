package semi_project.test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.DayOfWeek;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DateSelection extends JFrame implements ActionListener {
	
//	Container cont = this.getContentPane();
	
	SeatSelection seatsel = new SeatSelection(); // JPanel로 만들어서 붙이면 해결가능 By선생님
	Calendar cal = Calendar.getInstance();
	int week = cal.get(Calendar.DAY_OF_WEEK);
	
	String seat_num;
	
	JPanel jp_main = new JPanel();
		JPanel jp_title = new JPanel(new GridLayout(1,7));
		JPanel jp_center = new JPanel(new GridLayout(0,7));
		
	JPanel jp_South = new JPanel();
		
	JButton jbtn_title[] = new JButton[7];
	JButton jbtn_day[] = new JButton[31];
	JButton jbtn_next = new JButton("다음");
	
	String dayOfWeek[] = {"Mon", "Tue", "Wen", "Thu", "Fri", "Sat", "Sun"};
	
	int year = cal.get(Calendar.YEAR);
	int month = cal.get(Calendar.MONTH)+1;
	int date = cal.get(Calendar.DATE);
	
	public DateSelection() {
		initDisplay();
	}
	
	public void initDisplay() {
		int std=0;
		
		cal.set(year, month-1, 1);
		int week =cal.get(Calendar.DAY_OF_WEEK);
		for(int i=0; i<7; i++) {
			jbtn_title[i] = new JButton(dayOfWeek[i]);
			jbtn_title[i].setBackground(Color.LIGHT_GRAY);
			jbtn_title[i].setPreferredSize(new Dimension(60, 30));
			jp_title.add(jbtn_title[i]);
		}
		
		int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
		
		for(int i=0; i<week-1; i++) {
			JButton jbtn_null = new JButton("");
			jbtn_null.setBackground(Color.WHITE);
			jbtn_null.setPreferredSize(new Dimension(60, 30));
			jbtn_null.addActionListener(this);
			jp_center.add(jbtn_null);
			std++;
			if(std==7) std=0;
		}
		for(int i=0; i<cal.getActualMaximum(cal.DAY_OF_MONTH); i++) {
			jbtn_day[i] = new JButton(String.valueOf(i+1));
			jbtn_day[i].setBackground(Color.WHITE);
			jbtn_day[i].addActionListener(this);
			jp_center.add(jbtn_day[i]);
			std++;
			if(std==7) std=0;
		}

		for(int i=std; i<7; i++) {
			JButton jbtn_null = new JButton("");
			jbtn_null.setBackground(Color.WHITE);
			jbtn_null.setPreferredSize(new Dimension(60, 30));
			jp_center.add(jbtn_null);
		}
		jbtn_next.addActionListener(this);
		jp_main.add("North", jp_title);
		jp_main.add("Center", jp_center);
		jp_South.add(jbtn_next);
		this.add("South",jp_South);
		this.add("Center",jp_main);
		this.setSize(500, 500);
		this.setResizable(false);
		this.setVisible(true);
	}
		
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		for(int i=0; i<31; i++) {
			if(obj == jbtn_day[i]) { // 날짜버튼 눌렀을 때
				if(jbtn_day[i].getBackground() == Color.GRAY) { // 날짜 선택되있을 때,
					jbtn_day[i].setBackground(Color.WHITE); // 배경색 원래대로 복구
					return;
				}
				else { 
					for(int j=0; j<31; j++) {
						jbtn_day[j].setBackground(Color.WHITE); // 배경색 모두 초기화
					}
					jbtn_day[i].setBackground(Color.GRAY); // 배경색 회색으로 변경.
				}
			}
		}
		if(obj == jbtn_next) {
			int change = 0;
			for(int i=0; i<31; i++) {
				if(jbtn_day[i].getBackground() == Color.GRAY) { //선택된 날짜가 있는지 조회
					change = 1; // 선택된 날짜가 있으면 change변수 1로 변경
				}
			}
			if(change == 0) {
				System.out.println("날짜를 선택하세요");
				return; //선택된 날짜가 없으면 리턴.
			}
			
			seatsel = new SeatSelection();
			seatsel.initDisplay();
			this.setVisible(false);
//			this.setSize(700,700);
//			this.setLayout(new BorderLayout());
//			cont.revalidate();
//			cont.removeAll();
//			this.add("Center",seatsel.jp_center);
//			this.add("South",seatsel.jp_south);
		}
	}
}

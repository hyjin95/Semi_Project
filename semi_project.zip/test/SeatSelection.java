package semi_project.test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SeatSelection extends JFrame implements ActionListener {
	
	Payment pm = new Payment();
	
	JPanel jp_center = new JPanel(new FlowLayout());
		JButton jbtn_seat[] = new JButton[96];
	JPanel jp_south = new JPanel();
		JButton jbtn_next = new JButton("다음");
	
//	Container cont = this.getContentPane();

	String seat_choice[] = new String[96];
	int change = 0;

	public SeatSelection() { // 생성자
		for(int i=0; i<96; i++) {
			String seat = Integer.toString(i+1);
			jbtn_seat[i] = new JButton(seat);
			jbtn_seat[i].setBackground(Color.GRAY);
			jbtn_seat[i].setPreferredSize(new Dimension(50, 30));
			jbtn_seat[i].addActionListener(this);
			jp_center.add(jbtn_seat[i]);
		}
		jp_south.add(jbtn_next);
		jbtn_next.addActionListener(this);
	}
	
	public void initDisplay() {
		this.setSize(700, 700);
		this.setLayout(new BorderLayout());
		this.add("Center",jp_center);
		this.add("South",jp_south);
		this.setResizable(false);
		this.setVisible(true);
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		
		for(int i=0; i<96; i++) {
			if(obj == jbtn_seat[i]) { // 좌석버튼 눌렀을 때,
				if(jbtn_seat[i].getText()==null) { // 좌석명이 null일 때
					String seat = Integer.toString(i+1); // 임시변수 seat(좌석번호를 저장)
					jbtn_seat[i].setBackground(Color.GRAY); // 배경색 원래대로
					jbtn_seat[i].setText(seat); // 버튼에 좌석번호 다시 부여
					change--;
					return;
				}
				jbtn_seat[i].setBackground(Color.BLACK); // 배경색 검정색으로
				jbtn_seat[i].setText(null); //좌석명 null로
				change++;
			}
		}
		
		if(obj == jbtn_next) { // 다음버튼 눌렀을 때
			if(change==0) {
				System.out.println("좌석을 1석 이상 선택하세요.");
				return;
			}
			for(int i = 0; i<96; i++) {
				if(jbtn_seat[i].getText() == null) { // 좌석명이 없는번호 산출
					String num = Integer.toString(i); // 좌석번호 문자열로 변환
					seat_choice[i] = num; // 선택한 좌석들을 변수(seat_choice 배열)에 저장
				}
			}
			pm.initDisplay();
			this.setVisible(false);
//			cont.removeAll(); // 디스플레이 초기화, 다른 component 추가해주면 지연없이 넘어갈 수 있음.(뒤로가기도 가능)
//			this.setSize(400, 400);
//			this.add("South", pm.jp_south);
//			cont.revalidate(); // 반영
		}
	}

}

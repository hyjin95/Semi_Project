package semi_project.test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class ShowMovieList extends JFrame implements ActionListener {
	MovieMainView mmv = null;
	JScrollPane jsp = null;
	JPanel jp_center = new JPanel();
	JPanel jp_south = new JPanel();
	
	JButton jbtn_prev = new JButton("뒤로가기");
	
	public void initDisplay() {
		jp_south.add(jbtn_prev);
		jbtn_prev.addActionListener(this);
		jsp = new JScrollPane(jp_center,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jsp.add(jp_center);
		this.add("Center", jsp);
		this.add("South", jp_south);
		this.setSize(700, 500);
		this.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == jbtn_prev) {
			mmv = new MovieMainView();
			mmv.initDisplay();
			this.setVisible(false);
		}
	}
//	public static void main(String[] args) {
//		new ShowMovieList().initDisplay();
//	}
}

package semi_project.test; //첫화면

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MovieMainView extends JFrame implements ActionListener {
	DateSelection datesel = null;
	MovieSelection ms = null;
	ShowMovieList sh = null;
	Payment pm = null;
	public static int Ticketing_num;

	JPanel jp_center = null;
		JButton jbtn_list = new JButton("영화 목록");
		JButton jbtn_reservation = new JButton("영화 예매");
		JButton jbtn_confirm = new JButton("예매 확인");
	JPanel jp_south = new JPanel();
		JButton jbtn_exit = new JButton("닫기");

	public void initDisplay() {
		jp_center = new JPanel();
		jp_center.setLayout(null);
		jbtn_list.setBounds(150, 50, 100, 40);
		jbtn_reservation.setBounds(150, 110, 100, 40);
		jbtn_confirm.setBounds(150, 170, 100, 40);
			jp_center.add(jbtn_list);
			jp_center.add(jbtn_reservation);
			jp_center.add(jbtn_confirm);
			
		jp_south.setLayout(new FlowLayout());
		jp_south.add("Center",jbtn_exit);
		
		jbtn_list.addActionListener(this);
		jbtn_reservation.addActionListener(this);
		jbtn_confirm.addActionListener(this);
		jbtn_exit.addActionListener(this);

		this.add("Center", jp_center);
		this.add("South", jp_south);
		this.setTitle("Movie Ver 1.0");
		this.setSize(400, 400);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		new MovieMainView().initDisplay();
	}

	public void showNum() {
		if(Ticketing_num == 0) {
			JOptionPane.showMessageDialog(null, "고객님은 예매하지 않으셨습니다!"
					,"예매확인", JOptionPane.WARNING_MESSAGE);
		}
		else {
			JOptionPane.showMessageDialog(null, "고객님의 예매번호는 " + 
				Ticketing_num + "입니다!", "예매확인", JOptionPane.PLAIN_MESSAGE);
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		if (obj == jbtn_list) {
			sh = new ShowMovieList();
			sh.initDisplay();
			this.setVisible(false);
		}
		else if (obj == jbtn_reservation) {
			ms = new MovieSelection();
			ms.initDisplay();
			this.setVisible(false);
		}
		else if (obj == jbtn_confirm) {
			showNum();
		}
		else if (obj == jbtn_exit) {
			System.exit(0);
		}
	}
}
package semi_project.test;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class MovieSelection extends JFrame implements ActionListener {
	DateSelection ds = null;
	
	JScrollPane jsp = null;
	JPanel jp_center = new JPanel();
	JPanel jp_east = new JPanel(new GridLayout(1,7,25,25));
	JPanel jp_south = new JPanel();

	JButton jbtn_sel[] = new JButton[7];
	JButton jbtn_next = new JButton("다음");
	
	public void initDisplay() {
		jsp = new JScrollPane(jp_center,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jp_south.add(jbtn_next);
		
//		jsp.add("Center",jp_center);
//		jsp.add("East",jp_east);
//		
//		for(int i=0; i<7; i++) {
//			jbtn_sel[i] = new JButton();
//			jbtn_sel[i].setPreferredSize(new Dimension(50, 30));
//			jbtn_sel[i].addActionListener(this);
//		}
		
		jbtn_next.addActionListener(this);
		this.setLayout(new BorderLayout());
		this.setTitle("영화 선택");
		this.add("Center", jsp);
		this.add("South", jp_south);
		this.setSize(700, 500);
		this.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == jbtn_next) {
			ds = new DateSelection();
			this.setVisible(false);
		}
	}
	
//	public static void main(String[] args) {
//		new MovieSelection().initDisplay();
//	}
	
}
